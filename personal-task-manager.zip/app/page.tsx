"use client"

import { Sidebar } from "../src/components/Sidebar"

export default function SyntheticV0PageForDeployment() {
  return <Sidebar />
}