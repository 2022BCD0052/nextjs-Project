import { NextResponse } from "next/server"
import { db } from "@/db"
import { tasks, insertTaskSchema } from "@/db/schema"
import { eq } from "drizzle-orm"
import { getServerSession } from "next-auth"

export async function GET(req: Request) {
  const session = await getServerSession()
  if (!session || !session.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const userId = Number.parseInt(session.user.id)
  const allTasks = await db.select().from(tasks).where(eq(tasks.userId, userId))
  return NextResponse.json(allTasks)
}

export async function POST(req: Request) {
  const session = await getServerSession()
  if (!session || !session.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const userId = Number.parseInt(session.user.id)
  const body = await req.json()
  const validatedData = insertTaskSchema.parse({ ...body, userId })

  const newTask = await db.insert(tasks).values(validatedData).returning()
  return NextResponse.json(newTask[0])
}

