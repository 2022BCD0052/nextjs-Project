export const applicationName = "APP";

export const afterLoginUrl = "/dashboard";
