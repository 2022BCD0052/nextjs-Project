export const btnIconStyles = "w-4 h-4";

export const btnStyles = "flex gap-2 items-center";

export const socialIconStyles =
  "cursor-pointer dark:hover:fill-slate-400 w-8 h-8 dark:fill-white";
