/** Auto-generated **/
declare const map: Record<string, unknown>;

export { map };
